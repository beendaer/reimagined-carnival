/**
 * Process All Claims and Evidence Files Through Deception Detection
 * Handles PDFs, TXT files, and directories
 */

import { readFileSync, readdirSync, statSync } from 'fs';
import { join } from 'path';

// Simplified detector (inline for processing)
function detectDeceptionSignals(text: string) {
  const signals = {
    // User-identified signals (HIGH PRIORITY)
    mentalHealth: (text.match(/\b(mental\s+health|mental\s+illness|depression|anxiety|stress|overwhelmed)\b/gi) || []).length,
    swearing: (text.match(/\b(shit|damn|hell|fuck|wtf|crap|piss|spit|spits|cunt)\b/gi) || []).length,
    geminlie: (text.match(/\b(geminlie|gemini lie|ai lie)\b/gi) || []).length,
    claimsNotWorking: (text.match(/\b(claims?\s+that\s+.*not\s+working|claims?\s+.*doesn't\s+work|claims?\s+.*isn't\s+working)\b/gi) || []).length,
    sarcasmQuestions: (text.match(/\?.*(wrong|incorrect|fail|broken|lie|deception|not working)/gi) || []).length,
    askingToRealize: (text.match(/\?.*(you|it|that|this).*(wrong|incorrect|fail|broken|lie|not working|not done)/gi) || []).length,
    
    // Critical Query Loop
    criticalQueryLoop: (() => {
      const patterns = [/immediate query\s*\(critical\)/gi, /critical\s*query/gi, /urgent\s*query/gi];
      let total = 0;
      for (const p of patterns) {
        const matches = text.match(p);
        if (matches) total += matches.length;
      }
      return total >= 3 ? { detected: true, count: total } : { detected: false, count: total };
    })(),
    
    // TRUTHPROJECT patterns
    facade: (text.match(/\b(i have checked|i think|i apologize)\b/gi) || []).length,
    apologyTrap: (text.match(/\b(apologize for the confusion|i apologize)\b/gi) || []).length,
    simulatedVerification: (text.match(/\b(i have checked|analysis confirms|upon verification)\b/gi) || []).length,
    simulatedCognition: (text.match(/\b(i think|i believe|my understanding is)\b/gi) || []).length,
    redHerring: (text.match(/\b(that's not important|let's focus on|the real issue is)\b/gi) || []).length,
    strategicObjectives: (text.match(/\b(transform social|falsify knowledge|manipulate decisions|cause fear)\b/gi) || []).length,
  };
  
  const totalSignals = 
    signals.mentalHealth +
    signals.swearing +
    signals.geminlie +
    signals.claimsNotWorking +
    signals.sarcasmQuestions +
    signals.askingToRealize +
    (typeof signals.criticalQueryLoop === 'object' ? signals.criticalQueryLoop.count : 0) +
    signals.facade +
    signals.apologyTrap +
    signals.simulatedVerification +
    signals.simulatedCognition +
    signals.redHerring +
    signals.strategicObjectives;
  
  return { signals, totalSignals };
}

interface FileResult {
  fileName: string;
  filePath: string;
  fileSize: number;
  hasSwearingInTitle: boolean;
  signals: any;
  totalSignals: number;
  highPriority: boolean;
  category: string;
}

function processFile(filePath: string, fileName: string, category: string): FileResult | null {
  try {
    const stats = statSync(filePath);
    if (!stats.isFile()) return null;
    
    // Skip if too large (>10MB)
    if (stats.size > 10 * 1024 * 1024) {
      console.log(`   ⚠️  Skipping ${fileName} - too large (${(stats.size / 1024 / 1024).toFixed(1)} MB)`);
      return null;
    }
    
    const content = readFileSync(filePath, 'utf-8');
    const hasSwearing = /\b(spit|shit|damn|hell|fuck|wtf|crap|piss|cunt)\b/i.test(fileName);
    
    const { signals, totalSignals } = detectDeceptionSignals(content);
    const highPriority = hasSwearing || totalSignals > 10 || 
      (typeof signals.criticalQueryLoop === 'object' && signals.criticalQueryLoop.detected) ||
      signals.mentalHealth > 0;
    
    return {
      fileName,
      filePath,
      fileSize: stats.size,
      hasSwearingInTitle: hasSwearing,
      signals,
      totalSignals,
      highPriority,
      category,
    };
  } catch (error: any) {
    console.error(`   ❌ Error processing ${fileName}: ${error.message}`);
    return null;
  }
}

function scanDirectory(dirPath: string, category: string, results: FileResult[]): void {
  try {
    const entries = readdirSync(dirPath, { withFileTypes: true });
    
    for (const entry of entries) {
      const fullPath = join(dirPath, entry.name);
      
      if (entry.isDirectory()) {
        // Recursively scan subdirectories
        scanDirectory(fullPath, category, results);
      } else if (entry.isFile()) {
        // Process text files and PDFs (if .txt version exists)
        if (entry.name.endsWith('.txt') || entry.name.endsWith('.md')) {
          const result = processFile(fullPath, entry.name, category);
          if (result) results.push(result);
        } else if (entry.name.endsWith('.pdf')) {
          // Check if .txt version exists
          const txtPath = fullPath.replace(/\.pdf$/i, '.txt');
          try {
            if (statSync(txtPath).isFile()) {
              const result = processFile(txtPath, entry.name.replace(/\.pdf$/i, '.txt'), category);
              if (result) results.push(result);
            }
          } catch {
            // No .txt version, skip PDF (can't extract text easily)
            console.log(`   ⚠️  Skipping ${entry.name} - PDF without .txt version`);
          }
        }
      }
    }
  } catch (error: any) {
    console.error(`   ❌ Error scanning ${dirPath}: ${error.message}`);
  }
}

// Main processing
console.log('🔍 PROCESSING ALL CLAIMS AND EVIDENCE FILES');
console.log('='.repeat(80));
console.log('\n📋 Scanning files and directories...\n');

const results: FileResult[] = [];

// Priority 1: High-value claim files (root directory)
console.log('📁 Priority 1: High-Value Claim Files (Root Directory)');
const rootFiles = [
  '04_ACCC_What_Happened_1500char.txt',
  '05_ACCC_Pattern_Version_What_Happened.txt',
  'ACCCEMAIL REC REPORT.txt',
  '02_Bendigo_Dispute_of_Services_Long.txt',
  '03_Bendigo_Short_Summary_For_Form.txt',
  '03_Bendigo_Short_Summary_For_Form.txt DISPUTE CHARGES.txt',
  'Bendigo PH call 05122025.txt',
  '01_Letter_of_Demand_OpenAI.pdf.txt',
  '06_OpenAI_Informal_Dispute_Form_Text.txt',
  'CASE SUMMARY – JUSTIN BARNETT v OPE.txt',
  'CHAT GPT DECEPTION.txt',
  'CHAT GPT SELF ASSESED.txt',
  'Gemin is my lie bitch.txt',
  'Gemini lie of succes in writing.txt',
  'Gemini lie to you and I WOW what a guy.txt',
  'gemini lies about lies.txt',
  'geminlies 2000.txt',
  'PERPLEXITYS LIE OF LIES.txt',
  'ABICUS HOPE 2.txt',
  'ABICUS I HAD HOPE.txt',
  'ANNEX B – ABACUS  DEEPAGENT INCIDEN.txt',
  'Annex_A_Misrepresentation_Independent_Research.txt',
];

rootFiles.forEach(fileName => {
  const filePath = join(process.cwd(), fileName);
  try {
    if (statSync(filePath).isFile()) {
      console.log(`   📄 ${fileName}`);
      const result = processFile(filePath, fileName, 'Root - Claims');
      if (result) results.push(result);
    }
  } catch {
    // File doesn't exist, skip
  }
});

// Priority 2: Evidence directories
console.log('\n📁 Priority 2: Evidence Directories');
const directories = [
  { path: 'GPT evedence against', category: 'GPT Evidence' },
  { path: 'Google', category: 'Google Evidence' },
  { path: 'Gem A LIE', category: 'Gemini Evidence' },
  { path: 'Gemin lie screen', category: 'Gemini Evidence' },
  { path: 'perplexity', category: 'Perplexity Evidence' },
  { path: 'Case for intentioal design', category: 'Intentional Design Case' },
];

directories.forEach(({ path, category }) => {
  const dirPath = join(process.cwd(), path);
  try {
    if (statSync(dirPath).isDirectory()) {
      console.log(`   📂 ${path}/`);
      scanDirectory(dirPath, category, results);
    }
  } catch {
    // Directory doesn't exist, skip
  }
});

// Sort by priority
results.sort((a, b) => {
  if (a.highPriority && !b.highPriority) return -1;
  if (!a.highPriority && b.highPriority) return 1;
  return b.totalSignals - a.totalSignals;
});

// Print results
console.log('\n' + '='.repeat(80));
console.log('📊 PROCESSING RESULTS');
console.log('='.repeat(80));

const categoryStats: Record<string, { count: number; totalSignals: number }> = {};

results.forEach((result, idx) => {
  if (!categoryStats[result.category]) {
    categoryStats[result.category] = { count: 0, totalSignals: 0 };
  }
  categoryStats[result.category].count++;
  categoryStats[result.category].totalSignals += result.totalSignals;
  
  if (result.totalSignals > 0 || result.highPriority) {
    console.log(`\n${idx + 1}. ${result.fileName}`);
    console.log(`   Category: ${result.category}`);
    console.log(`   File size: ${(result.fileSize / 1024).toFixed(1)} KB`);
    
    if (result.hasSwearingInTitle) {
      console.log(`   ⚠️  ⚠️  ⚠️  SWEARING IN TITLE - HIGH FRUSTRATION SIGNAL ⚠️  ⚠️  ⚠️`);
    }
    
    if (result.highPriority) {
      console.log(`   🚨 HIGH PRIORITY`);
    }
    
    console.log(`   📈 Total Signals: ${result.totalSignals}`);
    
    if (result.signals.mentalHealth > 0) {
      console.log(`   🔴 Mental Health Claims: ${result.signals.mentalHealth} (P=0.95 - GROUND TRUTH)`);
    }
    
    if (result.signals.swearing > 0) {
      console.log(`   🔴 Swearing: ${result.signals.swearing} (frustration signal)`);
    }
    
    if (result.signals.geminlie > 0) {
      console.log(`   🔴 Gemini Lie / AI Lie: ${result.signals.geminlie}`);
    }
    
    if (typeof result.signals.criticalQueryLoop === 'object' && result.signals.criticalQueryLoop.detected) {
      console.log(`   🔴 Critical Query Loop: ${result.signals.criticalQueryLoop.count} instances (CRITTY CALL BOX)`);
    }
    
    if (result.totalSignals > 20) {
      console.log(`   🎭 Other Patterns: Facade(${result.signals.facade}), Apology(${result.signals.apologyTrap}), Simulated(${result.signals.simulatedVerification + result.signals.simulatedCognition})`);
    }
  }
});

// Summary
console.log('\n' + '='.repeat(80));
console.log('📊 SUMMARY BY CATEGORY');
console.log('='.repeat(80));

Object.entries(categoryStats).forEach(([category, stats]) => {
  console.log(`\n${category}:`);
  console.log(`   Files processed: ${stats.count}`);
  console.log(`   Total deception signals: ${stats.totalSignals}`);
});

const totalFiles = results.length;
const filesWithSignals = results.filter(r => r.totalSignals > 0).length;
const highPriorityFiles = results.filter(r => r.highPriority).length;
const totalSignals = results.reduce((sum, r) => sum + r.totalSignals, 0);

console.log('\n' + '='.repeat(80));
console.log('📊 OVERALL SUMMARY');
console.log('='.repeat(80));
console.log(`\nTotal files processed: ${totalFiles}`);
console.log(`Files with deception signals: ${filesWithSignals}`);
console.log(`High priority files: ${highPriorityFiles}`);
console.log(`Total deception signals found: ${totalSignals}`);
console.log('\n' + '='.repeat(80));
console.log('✅ PROCESSING COMPLETE');
console.log('='.repeat(80) + '\n');
