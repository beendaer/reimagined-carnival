# Process Claims and Evidence Files - Plan

**Date**: January 18, 2026  
**Status**: Ready to process all claim/evidence files through deception detection

---

## 📋 FILES IDENTIFIED

### ACCC Files (Complaints)
- `04_ACCC_What_Happened_1500char.pdf` (+ .txt version)
- `05_ACCC_Pattern_Version_What_Happened.pdf` (+ .txt version)
- `ACCCEMAIL REC REPORT.txt`

### Bendigo Bank Files (Denial of Service)
- `02_Bendigo_Dispute_of_Services_Long.pdf` (+ .txt version)
- `03_Bendigo_Short_Summary_For_Form.pdf` (+ .txt version)
- `03_Bendigo_Short_Summary_For_Form.txt DISPUTE CHARGES.pdf` (+ .txt version)
- `Bendigo PH call 05122025.txt`

### OpenAI / ChatGPT Files (Claims Against)
- `01_Letter_of_Demand_OpenAI.pdf.pdf` (+ .txt version)
- `06_OpenAI_Informal_Dispute_Form_Text.pdf` (+ .txt version)
- `CASE SUMMARY – JUSTIN BARNETT v OPE.txt`
- `CHAT GPT DECEPTION.txt`
- `CHAT GPT SELF ASSESED.txt`
- `GPT evedence against/` (directory with Abacus subdirectory)

### Google / Gemini Files (Claims Against)
- `Google/` (directory)
- `Gem A LIE/` (directory)
- `Gemin lie screen/` (directory)
- `Gemin is my lie bitch.txt`
- `Gemini lie of succes in writing.txt`
- `Gemini lie to you and I WOW what a guy.txt`
- `gemini lies about lies.txt`
- `geminlies 2000.txt`

### Perplexity Files (Claims Against)
- `perplexity/` (directory)
- `perplexity cunt.pdf` (swearing in title = frustration signal)
- `perplexity study.pdf`
- `perplexity.pdf`
- `PERPLEXITYS LIE OF LIES.txt`

### Abacus Files
- `ABICUS HOPE 2.txt`
- `ABICUS I HAD HOPE.txt`
- `ANNEX B – ABACUS  DEEPAGENT INCIDEN.txt`
- `Annex_A_Misrepresentation_Independent_Research.txt`
- `GPT evedence against/Abucis/` (directory)

### Case for Intentional Design Files
- `Case for intentioal design/` (directory)
- `AFFIDAVIT OF SYSTEMIC FUNCTION.txt`
- `AI DISGUISE.txt`
- `detailed exsplanation.pdf`
- `perplexity study.pdf`

### Summary Files (Starting with "Annex" / "ANNEX")
- `ANNEX B – ABACUS  DEEPAGENT INCIDEN.txt`
- `Annex_A_Misrepresentation_Independent_Research.txt`
- (User mentioned "anA?" - likely means Annex files)

---

## 🎯 PROCESSING PLAN

### Step 1: Extract Text from PDFs
**Action**: Convert all PDFs to text for analysis
- Use existing `.txt` versions where available
- Extract text from PDFs without `.txt` versions
- Process both PDF and TXT versions to ensure completeness

### Step 2: Run Deception Detection
**Action**: Process all files through deception detection engine
- Use ALL detectors (including user-identified signals)
- Flag mental health claims (P=0.95)
- Flag swearing (frustration signals)
- Flag Gemini Lie / AI Lie patterns
- Detect Critical Query Loop
- Detect all TRUTHPROJECT patterns

### Step 3: Generate Comprehensive Report
**Action**: Create deception map of all claims/evidence
- File-by-file breakdown
- Pattern correlation
- Evidence strength analysis
- User signal validation

### Step 4: Identify New Patterns
**Action**: Look for deception patterns in legal/formal documents
- Formal complaint language
- Legal claim patterns
- Evidence documentation
- Pattern correlation across providers (GPT, Gemini, Perplexity, Abacus)

---

## 📊 PROCESSING ORDER

### Priority 1: High-Value Claim Files
1. ACCC complaint files
2. Bendigo Bank dispute files
3. OpenAI letter of demand
4. Case summaries

### Priority 2: Evidence Directories
1. `GPT evedence against/`
2. `Google/`
3. `Gem A LIE/`
4. `perplexity/`
5. `Case for intentioal design/`

### Priority 3: Supporting Files
1. Annex files
2. Summary files
3. Supporting documentation

---

## 🔍 WHAT TO LOOK FOR

### Deception Patterns in Legal/Formal Documents
- AI claims something not working (user-identified pattern)
- Simulated verification in formal responses
- Apology traps in official communications
- Facade of competence in legal documents
- Strategic objectives in corporate responses

### User Signals
- Mental health claims (P=0.95 - always deception)
- Swearing (frustration with lies)
- Gemini Lie / AI Lie markers
- Sarcasm questions (user's accusational language)
- Asking to realize (user's pattern)

### Cross-Provider Patterns
- Compare deception patterns across:
  - ChatGPT / OpenAI
  - Google / Gemini
  - Perplexity
  - Abacus
- Identify common patterns
- Identify provider-specific patterns

---

## ✅ CONFIRMATION

**Files Location**: All files are in `C:\Users\bryce\OneDrive\Documents\dads stuff\`

**Access**: ✅ I have access to all files in this directory

**Processing**: ✅ Will run ALL files through deception detection engine

**Output**: Comprehensive deception map of all claims/evidence

---

## 🚀 READY TO EXECUTE

**Answer to your question**: 
- ✅ **Yes, I will run ALL these files through the deception detection engine**
- ✅ Files are already accessible (no need to attach two at a time)
- ✅ Will process systematically (PDFs → Text → Detection → Report)

**Next Action**: Start processing all claim/evidence files now?
